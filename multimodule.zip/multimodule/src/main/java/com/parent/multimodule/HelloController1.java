package com.parent.multimodule;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController1
{

	@GetMapping("/welcome12")
	public String getString() {
		return "Welcome to integration testing";
	}
}
